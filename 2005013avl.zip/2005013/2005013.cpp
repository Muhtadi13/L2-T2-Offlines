#include <bits/stdc++.h>
using namespace std;
#define lli long long int
#define endl "\n"
#define MOD 1000000007
#define cout out

template <class T>
class Node
{
    T value;
    Node *right;
    Node *left;
    int height;

public:
    void setValue(T v)
    {
        value = v;
    }

    T getValue()
    {
        return value;
    }

    void setRight(Node *x)
    {
        right = x;
    }
    Node *getRight()
    {
        return right;
    }
    void setLeft(Node *x)
    {
        left = x;
    }
    Node *getLeft()
    {
        return left;
    }
    void setHeight(int h)
    {
        height = h;
    }
    int getHeight()
    {
        return height;
    }
};

class BST
{

    int cnt;
    Node<int> *root;

    int trind;

    // ofstream out;

    void InOrder(Node<int> *root, ofstream &out)
    {
        if (root->getLeft())
            InOrder(root->getLeft(), out);

        cout << root->getValue() << " ";

        if (root->getRight())
            InOrder(root->getRight(), out);
    }
    void PreOrder(Node<int> *root, ofstream &out)
    {

        cout << root->getValue() << " ";

        if (root->getLeft())
            PreOrder(root->getLeft(), out);

        if (root->getRight())
            PreOrder(root->getRight(), out);
    }
    void PostOrder(Node<int> *root, ofstream &out)
    {

        if (root->getLeft())
            PostOrder(root->getLeft(), out);

        if (root->getRight())
            PostOrder(root->getRight(), out);

        cout << root->getValue() << " ";
    }

    void clear(Node<int> *root)
    {

        if (root->getLeft())
            clear(root->getLeft());

        if (root->getRight())
            clear(root->getRight());

        delete root;
    }
    void setHeightInTree(Node<int> *nd)
    {
        if (nd != NULL)
        {
            int h = 1;
            if (nd->getLeft() != NULL)
            {
                h = max(h, nd->getLeft()->getHeight() + 1);
            }
            if (nd->getRight() != NULL)
            {
                h = max(h, nd->getRight()->getHeight() + 1);
            }
            nd->setHeight(h);
            // cout<<nd->getHeight()<<"\n";
        }
    }

    Node<int> *leftRotate(Node<int> *nd)
    {
        // for right subtree of right child
        // nd---rc---rs(insert)

        Node<int> *tmp = nd->getRight();
        Node<int> *tmpl = tmp->getLeft();

        tmp->setLeft(nd);
        nd->setRight(tmpl);

        setHeightInTree(nd);
        setHeightInTree(tmp);

        return tmp;
    }
    Node<int> *rightRotate(Node<int> *nd)
    {
        Node<int> *tmp = nd->getLeft();
        Node<int> *tmpr = tmp->getRight();

        tmp->setRight(nd);
        nd->setLeft(tmpr);

        setHeightInTree(nd);
        setHeightInTree(tmp);

        return tmp;
    }

    Node<int> *leftRightRotate(Node<int> *nd)
    {
        nd->setLeft(leftRotate(nd->getLeft()));
        nd = rightRotate(nd);
        return nd;
    }
    Node<int> *rightLeftRotate(Node<int> *nd)
    {
        nd->setRight(rightRotate(nd->getRight()));
        nd = leftRotate(nd);
        return nd;
    }
    Node<int> *balance(Node<int> *par)
    {
        if (par == NULL)
            return par;

        int h1 = 0, h2 = 0;

        if (par->getLeft() != NULL)
            h1 = par->getLeft()->getHeight();
        if (par->getRight() != NULL)
            h2 = par->getRight()->getHeight();

        // cout<<h1<<h2<<"\n";

        if (h1 - h2 > 1)
        {
            int lh1 = 0, lh2 = 0;
            if (par->getLeft()->getRight() != NULL)
                lh2 = par->getLeft()->getRight()->getHeight();
            if (par->getLeft()->getLeft() != NULL)
                lh1 = par->getLeft()->getLeft()->getHeight();
            if (lh1 >= lh2)
                par = rightRotate(par);
            else
                par = leftRightRotate(par);
        }
        else if (h2 - h1 > 1)
        {
            int rh1 = 0, rh2 = 0;
            if (par->getRight()->getRight() != NULL)
                rh2 = par->getRight()->getRight()->getHeight();
            if (par->getRight()->getLeft() != NULL)
                rh1 = par->getRight()->getLeft()->getHeight();
            if (rh1 > rh2)
                par = rightLeftRotate(par);
            else
                par = leftRotate(par);
        }
        setHeightInTree(par);
        return par;
    }
    Node<int> *insertBalance(Node<int> *par, int num)
    {
        if (par == NULL)
            return par;
        int h1 = 0, h2 = 0;

        if (par->getLeft() != NULL)
            h1 = par->getLeft()->getHeight();
        if (par->getRight() != NULL)
            h2 = par->getRight()->getHeight();

        // cout<<h1<<h2<<"\n";

        if (h1 - h2 > 1)
        {
            if (par->getLeft() != NULL && par->getLeft()->getValue() > num)
                par = rightRotate(par);
            else
                par = leftRightRotate(par);
        }
        else if (h2 - h1 > 1)
        {
            if (par->getRight() != NULL && par->getRight()->getValue() < num)
                par = leftRotate(par);
            else
                par = rightLeftRotate(par);
        }
        setHeightInTree(par);
        return par;
    }

    Node<int> *delete_helper(Node<int> *nd, int num)
    {
        if (nd == NULL)
        {
            return nd;
        }
        if (num < nd->getValue())
        {
            nd->setLeft(delete_helper(nd->getLeft(), num));
        }
        else if (num > nd->getValue())
        {
            nd->setRight(delete_helper(nd->getRight(), num));
        }
        else
        {
            if ((nd->getLeft() == NULL) || (nd->getRight() == NULL))
            {

                Node<int> *tmp;
                tmp = NULL;

                if (nd->getLeft() != NULL)
                {
                    tmp = nd->getLeft();
                }

                else if (nd->getRight() != NULL)
                {
                    tmp = nd->getRight();
                    // cout << nd->getRight()->getValue() << "gdgd\n";
                }

                if (tmp == NULL)
                {
                    tmp = nd;
                    nd = NULL;
                }
                else
                {
                    nd->setHeight(tmp->getHeight());
                    nd->setLeft(tmp->getLeft());
                    nd->setRight(tmp->getRight());
                    nd->setValue(tmp->getValue());
                }

                free(tmp);
            }
            else
            {
                Node<int> *succ = nd->getRight();

                while (succ->getLeft() != NULL)
                    succ = succ->getLeft();

                // cout << succ->getValue() << "\n";

                nd->setValue(succ->getValue());
                nd->setRight(delete_helper(nd->getRight(), succ->getValue()));
            }
        }

        if (nd == NULL)
            return nd;

        nd = balance(nd);
        setHeightInTree(nd);
        return nd;
    }
    Node<int> *insertHelper(Node<int> *nd, int num)
    {
        if (nd == NULL)
        {
            // cout<<"qwerty"<<endl;
            nd = new Node<int>;
            nd->setValue(num);
            nd->setLeft(NULL);
            nd->setRight(NULL);
            nd->setHeight(1);
            cnt++;
            return nd;
        }

        if (nd->getValue() > num)
        {
            nd->setLeft(insertHelper(nd->getLeft(), num));
        }
        else if (nd->getValue() < num)
            nd->setRight(insertHelper(nd->getRight(), num));

        else
            return nd;

        nd = insertBalance(nd, num);
        return nd;
    }

public:
    BST()
    {
        root = NULL;
        // trind = 0;
        cnt = 0;
        // out.open("output.txt");
    }
    ~BST()
    {
        clear(root);
        // out.close();
    }

    double Insert(int num, ofstream &out)
    {
        chrono::steady_clock::time_point begin = chrono::steady_clock::now();
        root = insertHelper(root, num);
        chrono::steady_clock::time_point end = chrono::steady_clock::now();

        double t = chrono::duration_cast<chrono::nanoseconds>(end - begin).count();
        print(root, out);
        cout << "\n";

        return t;
    }

    double Delete(int num, ofstream &out)
    {
        if (root == NULL)
        {
            cout << "Tree is Empty" << endl;
            return 0;
        }

        chrono::steady_clock::time_point begin = chrono::steady_clock::now();
        root = delete_helper(root, num);
        chrono::steady_clock::time_point end = chrono::steady_clock::now();

        double t = chrono::duration_cast<chrono::nanoseconds>(end - begin).count();

        print(root, out);
        cout << "\n";

        return t;
    }

    double Find(int num,ostream &out)
    {
        chrono::steady_clock::time_point begin = chrono::steady_clock::now();

        bool f = false;

        if (root != NULL)
        {
            Node<int> *tmp = root;

            while (tmp != NULL)
            {
                if (tmp->getValue() < num)
                {
                    tmp = tmp->getRight();
                }
                else if (tmp->getValue() > num)
                {
                    tmp = tmp->getLeft();
                }
                else
                {
                    f = true;
                    break;
                }
            }
        }
        chrono::steady_clock::time_point end = chrono::steady_clock::now();
        double t = chrono::duration_cast<chrono::nanoseconds>(end - begin).count();

        if (f)
            cout << "found\n";
        else
            cout << "not found\n";

        return t;
    }

    double Traversal(string s, ofstream &out)
    {
        // int* traverse_array=new int[cnt+1];
        chrono::steady_clock::time_point begin = chrono::steady_clock::now();

        if (root == NULL)
        {
            cout << "Tree is Empty"
                 << "\n";
            return 0;
        }

        if (s == "In")
            InOrder(root, out);

        if (s == "Pre")
            PreOrder(root, out);

        if (s == "Post")
            PostOrder(root, out);

        cout << "\n";
        chrono::steady_clock::time_point end = chrono::steady_clock::now();
        double t = chrono::duration_cast<chrono::nanoseconds>(end - begin).count();
        return t;
        // return traverse_array;
    }

    void print(Node<int> *root, ofstream &out)
    {

        if (root)
        {
            cout << root->getValue();

            if (root->getLeft() || root->getRight())
            {
                cout << "(";

                print(root->getLeft(), out);
                // cout << ")";
                // cout << "(";
                cout << ",";
                print(root->getRight(), out);
                cout << ")";
            }
        }
    }
};

int main()
{
    ifstream in("in.txt");
    ofstream out("out_avl.txt");
    ofstream out2("report_avl.txt");
    if (!in)
    {
        cout << "Cannot open file" << endl;
        return -1;
    }

    BST bb;
    char com1;
    int com2;
    string com3;
    double instime = 0;
    int inscnt = 0;

    double deltime = 0;
    int delcnt = 0;

    double trtime = 0;
    int trcnt = 0;

    double findtime = 0;
    int findcnt = 0;
    int c=0;

    while (!in.eof())
    {
        //cout<<c++<<"\n";
        in >> com1;

        if (com1 == 'I')
        {
            in >> com2;
            instime += bb.Insert(com2, out);
            inscnt++;
           
        }
        else if (com1 == 'D')
        {
            in >> com2;
            deltime += bb.Delete(com2, out);
            delcnt++;
        }
        else if (com1 == 'F')
        {
            in >> com2;
            findtime += bb.Find(com2,out);
            findcnt++;
        }
        else if (com1 == 'T')
        {
            // in >> com3;
            trtime += bb.Traversal("In", out);
            trcnt++;
        }
        else
        {
            cout << "Wrong Input"<< "\n";
        }
        if (in.peek() == in.eof())
            break;
    }
   
   
    out2 << "operation time(ms)\n";
    out2 << setprecision(20) << "insert " << 0.000001 * instime << "\n";
    out2 << setprecision(20) << "delete " << 0.000001 * deltime << "\n";
    out2 << setprecision(20) << "searchtime " << 0.000001 * findtime << "\n";
    out2 << setprecision(20) << "trav " << 0.000001 * trtime << "\n";
    in.close();
    out.close();
    out2.close();

}