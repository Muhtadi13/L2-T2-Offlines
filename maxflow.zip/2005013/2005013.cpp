#include <bits/stdc++.h>
#define lli long long
#define plli pair<lli, lli>
#define MAX 2000
lli MOD = 1000000007LL;

using namespace std;

lli cap[MAX][MAX];
lli match[MAX][MAX];
vector<int> adj[MAX];
vector<plli> nodepair;
vector<lli> won(MAX);
vector<lli> remaining(MAX);
vector<string> mp(MAX);
lli n;

lli bfs(int source, int sink, vector<int> &prev)
{
    queue<int> pq;
    vector<bool> vis(MAX);
    lli ans = MOD;
    pq.push(source);
    while (!pq.empty())
    {
        int a = pq.front();
        pq.pop();
        if (a == sink)
            break;
        vis[a] = 1;
        for (auto u : adj[a])
        {
            int b = u;
            int rem = cap[a][b];
            if (vis[b] == 0 && rem > 0)
            {
                vis[b] = 1;
                // processed[b]=1;
                prev[b] = a;
                // cout<<a<<" "<<b<<"\n";
                pq.push(b);
            }
        }
    }
    if (prev[sink] == -1)
        return 0;
    lli cur = sink;
    while (cur != source && cur != -1)
    {
        int p = prev[cur];
        ans = min(ans, cap[p][cur]);
        cur = p;
    }
    return ans;
}
vector<lli> bfs_elimination(int source, int start)
{
    queue<int> pq;
    vector<bool> vis(MAX);
    lli ans = MOD;
    vis[source] = 1;
    pq.push(start);
    vector<lli> subset;
    while (!pq.empty())
    {
        int a = pq.front();
        pq.pop();
        vis[a] = 1;
        for (auto u : adj[a])
        {
            int b = u;
            int rem = cap[a][b];
            if (vis[b] == 0 && rem > 0)
            {
                vis[b] = 1;
                pq.push(b);
                if (b < n)
                    subset.push_back(b);
            }
        }
    }
    return subset;
}

void Edmond_Carp(lli n, lli source, lli sink, int gamecnt, lli who)
{
    lli max_flow = 0;
    while (true)
    {
        vector<int> prev(sink + 1, -1);
        lli val = bfs(source, sink, prev);
        if (val == 0)
            break;
        
        max_flow += val;
        int cur = sink;
        while (cur != source)
        {
            int p = prev[cur];
            if(cap[p][cur]!=MOD)
            cap[p][cur] -= val;

            if(cap[cur][p]!=MOD)
            cap[cur][p] += val;

            cur = p;
        }
    }
    bool ans = 0;
    lli ind = n;
    for (int i = 1; i <= gamecnt; i++)
    {
        if (cap[source][n + i] > 0)
        {
            //cout<<n+i<<"\n";
            ans = 1;
            ind = n + i;
            break;
        }
    }
    if (ans)
    {
        vector<lli> eliminator=bfs_elimination(source,ind);
        // for (int i = 0; i < n; i++)
        // {
        //     if (i == who)
        //         continue;
        //     if (cap[i][sink] == 0)
        //         eliminator.push_back(i);
        // }
        //sort(eliminator.begin(), eliminator.end());
        if (eliminator.size() == 0)
            return;
        lli v = 0;
        lli w = 0;
        for (int i = 0; i < eliminator.size(); i++)
        {
            w += won[eliminator[i]];
            for (int j = i + 1; j < eliminator.size(); j++)
                v += match[eliminator[i]][eliminator[j]];
        }

        cout << mp[who] << " is eliminated.\nThey can win at most " << won[who] << " + " << remaining[who] << " = " << won[who] + remaining[who] << " games.\n";
        for (int i = 0; i < eliminator.size(); i++)
        {
            if (i == eliminator.size() - 1)
                cout << mp[eliminator[i]];
            else
                cout << mp[eliminator[i]] << ", ";
        }
        cout << " have won a total of " << w << " games.\nThey play each other " << v << " times.\n";
        cout << "So on average, each of the teams in this group wins " << v + w << "/" << eliminator.size() << " = " << (1.0 * (v + w)) / eliminator.size() << " games.\n\n";
    }
}

int main()
{
    int t = 1;
    // cin>>t;
    while (t--)
    {
        // lli n;
        cin >> n;
        for (int i = 0; i < n; i++)
        {
            string s;
            cin >> s;
            mp[i] = s;
            int w, l, r;
            cin >> won[i] >> l >> remaining[i];
            for (int j = 0; j < n; j++)
                cin >> match[i][j];
        }
        lli source = n * n + n;
        lli sink = source + 1;
        for (int now = 0; now < n; now++)
        {
            bool triv = 0;
            for (int i = 0; i < n; i++)
            {
                if (now == i)
                    continue;
                if (won[now] + remaining[now] < won[i])
                {
                    triv = true;
                    cout << mp[now] << " is eliminated.\nThey can win at most " << won[now] << " + " << remaining[now] << " = " << won[now] + remaining[now] << " games.\n";
                    cout << mp[i] << " has won a total of " << won[i] << " games.\nThey play each other " << 0 << " times.\n";
                    cout << "So on average, each of the teams in this group wins " << won[i] << "/" << 1 << " = " << won[i] << " games.\n\n";
                    break;
                }
            }
            if (triv)
                continue;
            int gamecnt = 0;
            nodepair.clear();
            for (int i = 0; i <= sink; i++)
                adj[i].clear();
            memset(cap, 0, sizeof(cap));
            for (int i = 0; i < n; i++)
            {
                if (i == now)
                    continue;
                for (int j = i + 1; j < n; j++)
                {
                    if (now == j)
                        continue;
                    nodepair.push_back({i, j});
                    gamecnt++;
                    //cout<<gamecnt<<"\n";

                    adj[source].push_back(gamecnt + n);
                    adj[gamecnt + n].push_back(i);
                    adj[gamecnt + n].push_back(j);
                    adj[gamecnt + n].push_back(source);
                    adj[i].push_back(gamecnt + n);
                    adj[j].push_back(gamecnt + n);

                    cap[source][gamecnt + n] = match[i][j];
                    cap[gamecnt + n][i] = MOD;
                    cap[gamecnt + n][j] = MOD;
                    cap[gamecnt + n][source] = 0;
                    cap[i][gamecnt + n] = 0;
                    cap[j][gamecnt + n] = 0;
                }
                adj[i].push_back(sink);
                adj[sink].push_back(i);
                cap[i][sink] = won[now] + remaining[now] - won[i];
                cap[sink][i] = 0;
            }
            Edmond_Carp(n, source, sink, gamecnt, now);
        }
    }
}